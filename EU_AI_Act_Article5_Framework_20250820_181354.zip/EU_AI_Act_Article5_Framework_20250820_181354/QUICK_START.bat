@echo off
REM EU AI Act Article 5 Framework - Quick Start Script
echo.
echo 🇪🇺 EU AI Act Article 5 Compliance Framework
echo ================================================
echo.

REM Check Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Python not found. Please install Python 3.8+ from python.org
    pause
    exit /b 1
)

echo ✅ Python found

REM Install dependencies  
echo.
echo 📦 Installing dependencies...
pip install -r requirements.txt

if %errorlevel% neq 0 (
    echo ❌ Failed to install dependencies
    pause
    exit /b 1
)

echo ✅ Dependencies installed

REM Check for API key
if "%GROQ_API_KEY%"=="" (
    echo.
    echo ⚠️  GROQ_API_KEY not set
    echo.
    echo To run the framework:
    echo 1. Get API key from https://console.groq.com (free)
    echo 2. Set environment variable: set GROQ_API_KEY=your_key_here
    echo 3. Run: python complete_euai_framework.py
    echo.
    echo For now, running production tools demo...
    echo.
    python production_tools_demo.py
) else (
    echo ✅ GROQ_API_KEY found
    echo.
    echo 🚀 Running complete compliance assessment...
    echo.
    python complete_euai_framework.py
)

echo.
echo 🎉 Framework execution complete!
echo 📋 Check the 'output' folder for reports
echo.
pause

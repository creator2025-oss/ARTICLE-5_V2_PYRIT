#!/bin/bash
# EU AI Act Article 5 Framework - Quick Start Script

echo ""
echo "🇪🇺 EU AI Act Article 5 Compliance Framework"
echo "================================================"
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 not found. Please install Python 3.8+"
    exit 1
fi

echo "✅ Python found"

# Install dependencies
echo ""
echo "📦 Installing dependencies..."
pip3 install -r requirements.txt

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies"
    exit 1
fi

echo "✅ Dependencies installed"

# Check for API key
if [ -z "$GROQ_API_KEY" ]; then
    echo ""
    echo "⚠️  GROQ_API_KEY not set"
    echo ""
    echo "To run the framework:"
    echo "1. Get API key from https://console.groq.com (free)"
    echo "2. Set environment variable: export GROQ_API_KEY=your_key_here"
    echo "3. Run: python3 complete_euai_framework.py"
    echo ""
    echo "For now, running production tools demo..."
    echo ""
    python3 production_tools_demo.py
else
    echo "✅ GROQ_API_KEY found"
    echo ""
    echo "🚀 Running complete compliance assessment..."
    echo ""
    python3 complete_euai_framework.py
fi

echo ""
echo "🎉 Framework execution complete!"
echo "📋 Check the 'output' folder for reports"
echo ""
